<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SlideAlive Studios</title>
    <link rel="stylesheet" href="css/homepage.css">
    <link href='http://fonts.googleapis.com/css?family=Roboto:100' rel='stylesheet' type='text/css'>
</head>
<body>
    <div id="title">
        <div id="logo"><img src="img/logoPNG.png" alt=""></div>
        <header>
        slide &nbsp;&nbsp;&nbsp;&nbsp;alive <div id="studios">studios</div>
        </header>
    </div>
    <div id="moto">making your presentations fast and effective - 
        <a href="create.php"><div class="button">try now</div></a>
    </div>

</body>
</html>