<?php
	require_once('main.php');
	require_once('flickr.php');
	require_once('decode.php');
	require_once('drive.php');
	//require_once('../vendor/autoload.php');
?>