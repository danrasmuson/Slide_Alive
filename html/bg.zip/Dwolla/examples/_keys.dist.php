<?php

// Dwolla Secret Stuff
$apiKey = '';
$apiSecret = '';
$token = '';
$pin = '';