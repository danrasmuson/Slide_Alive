<?php
	/*
		SlideAlive Backend
		Copyright 2013 William Teder
		@WilliamTDR // wteder@hydreon.com
	*/
	require_once('include/list.php');
	main();
?>